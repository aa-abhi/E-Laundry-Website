﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Admin_login_Admin_Home : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["usr"] != null)
        {
            Label1.Text = Session["usr"].ToString();
        }
        else
        {
            Response.Redirect("U_Login.aspx");
        }
    }
    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {
        if (RadioButton1.Checked == true)
        {
            MultiView1.SetActiveView(View1);
        }
    }
    protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
    {
        if (RadioButton2.Checked == true)
        {
            MultiView1.SetActiveView(View2);
        }
    }
    protected void RadioButton3_CheckedChanged(object sender, EventArgs e)
    {
        if (RadioButton3.Checked == true)
        {
            MultiView1.SetActiveView(View3);
        }
    }
    protected void RadioButton4_CheckedChanged(object sender, EventArgs e)
    {
        if (RadioButton4.Checked == true)
        {
            MultiView1.SetActiveView(View4);
        }
    }
    protected void RadioButton5_CheckedChanged(object sender, EventArgs e)
    {
        if (RadioButton5.Checked == true)
        {
            MultiView1.SetActiveView(View5);
        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        LinkButton chk = (LinkButton)sender;
        GridViewRow gr = (GridViewRow)chk.Parent.Parent;
        GridViewRow grRow = (GridViewRow)(sender as Control).Parent.Parent;
        con = new SqlConnection(eLaundry.ConnectionString);
        con.Open();
        cmd = new SqlCommand("update U_Order set Status='Pending' where  Sr_No = @id", con);
        cmd.Parameters.Add("@id", SqlDbType.Int).Value = GridView1.DataKeys[gr.RowIndex].Value.ToString();
        if (cmd.ExecuteNonQuery() > 0)
        {

        }
    }
}