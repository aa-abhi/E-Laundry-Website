﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class User_Login_U_Feedback : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["usr"] != null)
        {
            Label1.Text = Session["usr"].ToString();
        }
        else
        {
            Response.Redirect("U_Login.aspx");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(eLaundry.ConnectionString);
        con.Open();
        cmd = new SqlCommand("insert into Feedback values(@U_name,@Name,@Message)", con);
        cmd.Parameters.Add("@U_name", SqlDbType.VarChar, 50).Value = Label1.Text;
        cmd.Parameters.Add("@Name", SqlDbType.VarChar, 50).Value = TextBox1.Text;
        cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500).Value = TextBox2.Text;
       
        if (cmd.ExecuteNonQuery() > 0)
        {
            Label2.Text = "Thank you.!";
            //Label1.ForeColor = System.Drawing.Color.Green;
        }
    }
}