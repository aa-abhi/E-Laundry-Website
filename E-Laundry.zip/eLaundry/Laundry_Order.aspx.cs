﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Laundry_Login_L_Order : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["usr"] != null)
        {
            Label1.Text = Session["usr"].ToString();
        }
        else
        {
            Response.Redirect("U_Login.aspx");
        }
    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        //LinkButton chk = (LinkButton)sender;
        //GridViewRow gvRow = (GridViewRow)chk.Parent.Parent;
        //GridViewRow gvRow = (GridViewRow)(sender as Control).Parent.Parent;
        //con = new SqlConnection(eLaundry.ConnectionString);
        //con.Open();
        //cmd = new SqlCommand("update U_Order set Status='Approved' where Sr.No = @id", con);
        //cmd.Parameters.Add("@id", SqlDbType.Int).Value = GridView1.DataKeys[gvRow.RowIndex].Value.ToString();
        //if (cmd.ExecuteNonQuery() > 0)
        //{

        //}
    }
    protected void LinkButton4_Click(object sender, EventArgs e)
    {
        //LinkButton chk = (LinkButton)sender;
        //GridViewRow gvRow = (GridViewRow)chk.Parent.Parent;
        //GridViewRow gvRow = (GridViewRow)(sender as Control).Parent.Parent;
        //con = new SqlConnection(eLaundry.ConnectionString);
        //con.Open();
        //cmd = new SqlCommand("update U_Order set Status='Delivered' where Sr.No=@id", con);
        //cmd.Parameters.Add("@id", SqlDbType.Int).Value = GridView1.DataKeys[gvRow.RowIndex].Value.ToString();
        //if (cmd.ExecuteNonQuery() > 0)
        //{

        //}
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        LinkButton chk = (LinkButton)sender;
        GridViewRow gr = (GridViewRow)chk.Parent.Parent;
        GridViewRow grRow = (GridViewRow)(sender as Control).Parent.Parent;
        con = new SqlConnection(eLaundry.ConnectionString);
        con.Open();
        cmd = new SqlCommand("update U_Order set Status='Pending' where  Sr_No = @id", con);
        cmd.Parameters.Add("@id", SqlDbType.Int).Value = GridView1.DataKeys[gr.RowIndex].Value.ToString();
        if (cmd.ExecuteNonQuery() > 0)
        {

        }
    }
}