﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class D_pages_U_Login : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
//   SqlCommand rd;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(eLaundry.ConnectionString);
        con.Open();
        cmd = new SqlCommand("select * from Regis where Mob_no = '" + TextBox1.Text + "' and Password ='" + TextBox2.Text + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            // Label1.Text= "Log in successfully!";
            Session.Add("usr", TextBox1.Text);
            Response.Redirect("Place_order.aspx");
        }
        else
        {
            Label1.Text = "Mobile number or password is incorrect!";
        }
    }
}