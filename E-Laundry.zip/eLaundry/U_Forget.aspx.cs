﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


public partial class D_pages_U_Forget : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataReader dr;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(eLaundry.ConnectionString);
        con.Open();
        cmd = new SqlCommand("select * from Regis where Mob_no ='" + TextBox1.Text + "'and Question ='" + DropDownList1.SelectedItem.Text + "' and Answer = '" + TextBox2.Text + "'", con);
        dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            Label1.Text = "Your password is " + dr[3].ToString();
            Label1.ForeColor = System.Drawing.Color.Green;
            //Session.Add("usr", TextBox1.Text);
           // Response.Redirect("ChangePassword.aspx");
        }
        else
        {
            Label1.Text = "Mobile Number or Questoin or Answer is incorrect";
            Label1.ForeColor = System.Drawing.Color.Red;
        }
    }
}