﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Place_order : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["usr"] != null)
        {
            Label1.Text = Session["usr"].ToString();
        }
        else
        {
            Response.Redirect("U_Login.aspx");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(eLaundry.ConnectionString);
        con.Open();
        cmd = new SqlCommand("insert into U_Order values(@College_Name,@Hostal_name,@Room_no,@No_of_clothes,@Mob_NO,@Select_Laundry,@U_Name,@Status)", con);
        cmd.Parameters.Add("@College_Name", SqlDbType.VarChar, 50).Value = DropDownList1.SelectedItem.Text;
        cmd.Parameters.Add("@Hostal_name", SqlDbType.VarChar, 50).Value = DropDownList2.SelectedItem.Text;
        cmd.Parameters.Add("@Room_no", SqlDbType.VarChar, 50).Value = DropDownList3.SelectedItem.Text;
        cmd.Parameters.Add("@No_of_clothes", SqlDbType.VarChar, 50).Value = DropDownList4.SelectedItem.Text;
        cmd.Parameters.Add("@Mob_NO", SqlDbType.VarChar, 50).Value = TextBox1.Text;
        cmd.Parameters.Add("@Select_Laundry", SqlDbType.VarChar, 50).Value = DropDownList5.SelectedItem.Text;
        cmd.Parameters.Add("@U_Name", SqlDbType.VarChar, 50).Value = Label1.Text;
        cmd.Parameters.Add("@Status", SqlDbType.VarChar, 50).Value = "Pending";
        // FileUpload1.SaveAs(Server.MapPath("UserImage" + "/" + FileUpload1.FileName));
        //cmd.Parameters.Add("@pic", SqlDbType.VarChar, 50).Value = "UserImage" + "/" + FileUpload1.FileName;
        if (cmd.ExecuteNonQuery() > 0)
        {
            Label2.Text = "Order Successfully.";
            Label2.ForeColor = System.Drawing.Color.Green;
        }
    }
}