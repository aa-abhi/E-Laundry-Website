﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class D_pages_U_Regis : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(eLaundry.ConnectionString);
        con.Open();
        cmd = new SqlCommand("insert into Regis values(@name,@mob,@email,@pass,@ques,@ans)", con);
        cmd.Parameters.Add("@name", SqlDbType.VarChar, 50).Value = TextBox1.Text;
        cmd.Parameters.Add("@mob", SqlDbType.VarChar, 50).Value = TextBox2.Text;
        cmd.Parameters.Add("@email", SqlDbType.VarChar, 50).Value = TextBox3.Text;
        cmd.Parameters.Add("@pass", SqlDbType.VarChar, 50).Value = TextBox4.Text;
        cmd.Parameters.Add("@ques", SqlDbType.VarChar, 50).Value = DropDownList1.SelectedItem.Text;
        cmd.Parameters.Add("@ans", SqlDbType.VarChar, 50).Value = TextBox6.Text;
       // FileUpload1.SaveAs(Server.MapPath("UserImage" + "/" + FileUpload1.FileName));
        //cmd.Parameters.Add("@pic", SqlDbType.VarChar, 50).Value = "UserImage" + "/" + FileUpload1.FileName;
        if (cmd.ExecuteNonQuery() > 0)
        {
            Label1.Text = "User Register Successfully!!";
            Label1.ForeColor = System.Drawing.Color.Green;
        }
    }
}
